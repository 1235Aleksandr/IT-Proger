function info(word){
console.log(word + '!');
//console.log('!');
}

function sum( a, b){
    var res = a + b;
    info(res)
    //console.log(res);
}

sum(5, 7);