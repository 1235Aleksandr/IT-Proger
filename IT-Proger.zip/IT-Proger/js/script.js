//document.write('JS cu')
//console.log('JS cu')
//console.error('JS отключена')
console.warn('лучше исправить,а то!!')