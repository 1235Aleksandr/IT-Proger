var num = 15;
var isHasHouse = true;

if (num ==5       ||         isHasHouse){
    console.log('OK');
} else if (num <10){
    console.log('Ok!');
} else if (num == 7){
    console.log('7');
} else if (num >=15){
    console.log('>15');
}
else {
    console.log('Error');
}