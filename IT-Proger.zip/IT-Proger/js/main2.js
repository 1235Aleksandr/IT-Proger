var stroka = 'Word';

switch (stroka) {
    case '4': console.log('Переменная со значением 4');
    break;
    case '45': console.log('Переменная со значением 45');
    break;
    case 'Word': console.log('Переменная со значением "Word"');
    break;
default:
    console.log("Default");
    break;
}