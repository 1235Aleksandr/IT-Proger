var att = [5, true, "stroka",5.7, 0, -100];
console.log(att.length);


var matrix = [
    [5,6,1], ["stroka",5.7, 0], [3.14, 25, 87]
];
matrix[1][0] = 90;
console.log(matrix)