/* Таймеры */

setTimeout(function(){
    console.log('Таймер сработал');
},2000);